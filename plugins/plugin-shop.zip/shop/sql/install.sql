-- 企业商城插件：建表 SQL（安装时由 Shop::install() 执行）

-- __PREFIX__ 会被替换为当前数据库表前缀



CREATE TABLE IF NOT EXISTS `__PREFIX__shop_after_sale` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `after_sale_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'refund',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `admin_remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `refunded_at` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_after_sale_no` (`after_sale_no`),
  KEY `idx_order` (`order_id`),
  KEY `idx_member` (`member_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='售后申请';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_cart` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sku_id` int(10) unsigned NOT NULL DEFAULT '0',
  `qty` int(11) NOT NULL DEFAULT '1',
  `selected` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_member_sku` (`member_id`,`sku_id`),
  KEY `idx_member` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='购物车（只存会员ID，不存会员资料）';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pid` (`pid`),
  KEY `idx_status_sort` (`status`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商城商品分类';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_coupon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `value` decimal(12,2) NOT NULL DEFAULT '0.00',
  `min_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` int(11) NOT NULL DEFAULT '0',
  `received` int(11) NOT NULL DEFAULT '0',
  `used` int(11) NOT NULL DEFAULT '0',
  `start_at` int(11) NOT NULL DEFAULT '0',
  `end_at` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_status_time` (`status`,`start_at`,`end_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券模板';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_coupon_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` int(10) unsigned NOT NULL DEFAULT '0',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `order_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `received_at` int(11) NOT NULL DEFAULT '0',
  `used_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_coupon_member` (`coupon_id`,`member_id`),
  KEY `idx_member_status` (`member_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='优惠券发放/使用记录';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `biz_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `member_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `staff_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending_payment',
  `pay_status` tinyint(4) NOT NULL DEFAULT '0',
  `pay_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `goods_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `member_discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `coupon_id` int(10) unsigned NOT NULL DEFAULT '0',
  `coupon_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `coupon_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `points_used` int(11) NOT NULL DEFAULT '0',
  `points_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `payable_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_rate` decimal(5,2) NOT NULL DEFAULT '1.00',
  `receiver` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mobile` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `province` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `district` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `address_json` text COLLATE utf8mb4_unicode_ci,
  `buyer_remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `admin_remark` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `express_company` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `express_no` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spend_state` tinyint(4) NOT NULL DEFAULT '0',
  `spend_before` decimal(12,2) NOT NULL DEFAULT '0.00',
  `spend_synced_at` int(11) NOT NULL DEFAULT '0',
  `stock_returned` tinyint(4) NOT NULL DEFAULT '0',
  `paid_at` int(11) NOT NULL DEFAULT '0',
  `shipped_at` int(11) NOT NULL DEFAULT '0',
  `completed_at` int(11) NOT NULL DEFAULT '0',
  `closed_at` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  UNIQUE KEY `uk_biz_no` (`biz_no`),
  KEY `idx_member` (`member_id`),
  KEY `idx_staff` (`staff_id`),
  KEY `idx_status` (`status`),
  KEY `idx_spend_state` (`spend_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商城订单主表（biz_no唯一，防重复提交）';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_order_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `product_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sku_id` int(10) unsigned NOT NULL DEFAULT '0',
  `product_title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sku_spec` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `qty` int(11) NOT NULL DEFAULT '1',
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `created_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商城订单明细快照';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_order_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `action` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `operator_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `operator_id` int(10) unsigned NOT NULL DEFAULT '0',
  `content` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_order` (`order_id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单操作日志';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cover` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `images` text COLLATE utf8mb4_unicode_ci,
  `detail` mediumtext COLLATE utf8mb4_unicode_ci,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `market_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `stock` int(11) NOT NULL DEFAULT '0',
  `sales` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `is_hot` tinyint(4) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_status_sort` (`status`,`sort`),
  KEY `idx_hot` (`is_hot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商城商品主表';

CREATE TABLE IF NOT EXISTS `__PREFIX__shop_sku` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sku_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spec_json` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '{}',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `market_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `stock` int(11) NOT NULL DEFAULT '0',
  `warn_stock` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` int(11) NOT NULL DEFAULT '0',
  `updated_at` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sku_code` (`sku_code`),
  KEY `idx_product` (`product_id`),
  KEY `idx_stock` (`stock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商城SKU与库存';
