<?php
$siteName = setting('site_name', '企业网站');
$logo = setting('site_logo', '');
$phone = setting('site_phone', '');
$email = setting('site_email', '');
$address = setting('site_address', '');
$copyright = setting('site_copyright', '© ' . date('Y') . ' ' . $siteName . ' 版权所有');
$icp = setting('site_icp', '');
$nav = $nav ?? [];
$pages = $pages ?? [];
$productCat = null;
foreach ($nav as $c) {
    if (($c['slug'] ?? '') === 'product') { $productCat = $c; }
}
$newsCat = null;
foreach ($nav as $c) {
    if (($c['slug'] ?? '') === 'news') { $newsCat = $c; }
}
$serviceCat = null;
foreach ($nav as $c) {
    if (($c['slug'] ?? '') === 'service') { $serviceCat = $c; }
}
?>
</main>

<footer class="wx-footer">
  <div class="wx-inner wx-footer-top">
    <div class="wx-fbrand">
      <a href="<?= e(lang_path('/')) ?>">
        <?php if ($logo): ?><img src="<?= e($logo) ?>" alt="<?= e($siteName) ?>"><?php else: ?><img src="/theme/logo.png" alt="<?= e($siteName) ?>"><?php endif; ?>
      </a>
      <p><?= e(setting('site_slogan', '材料，让制造更稳定')) ?></p>
      <span class="wx-fphone"><?= e($phone) ?></span>
    </div>
    <div class="wx-fcol">
      <h4><?= e(lang('产品中心')) ?></h4>
      <?php if ($productCat): ?>
        <a href="<?= e(lang_path('/c/' . $productCat['slug'])) ?>"><?= e($productCat['name']) ?></a>
        <?php foreach (($productCat['children'] ?? []) as $ch): ?>
          <a href="<?= e(lang_path('/c/' . $ch['slug'])) ?>"><?= e($ch['name']) ?></a>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
    <div class="wx-fcol">
      <h4><?= e(lang('新闻动态')) ?></h4>
      <?php if ($newsCat): ?>
        <a href="<?= e(lang_path('/c/' . $newsCat['slug'])) ?>"><?= e($newsCat['name']) ?></a>
      <?php endif; ?>
      <?php foreach ($pages as $p): ?>
        <?php if (in_array($p['slug'], ['about', 'culture'], true)): ?>
          <a href="<?= e(lang_path('/p/' . $p['slug'])) ?>"><?= e($p['title']) ?></a>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php if ($serviceCat): ?><a href="<?= e(lang_path('/c/' . $serviceCat['slug'])) ?>"><?= e($serviceCat['name']) ?></a><?php endif; ?>
    </div>
    <div class="wx-fcol">
      <h4><?= e(lang('关于我们')) ?></h4>
      <?php foreach ($pages as $p): ?>
        <?php if (!in_array($p['slug'], ['contact'], true)): ?>
          <a href="<?= e(lang_path('/p/' . $p['slug'])) ?>"><?= e($p['title']) ?></a>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>
    <div class="wx-fcol wx-fcontact">
      <h4><?= e(lang('联系我们')) ?></h4>
      <?php if ($phone): ?><a href="tel:<?= e(preg_replace('/[^0-9\-+]/', '', $phone)) ?>"><?= e($phone) ?></a><?php endif; ?>
      <?php if ($email): ?><a href="mailto:<?= e($email) ?>"><?= e($email) ?></a><?php endif; ?>
      <?php if ($address): ?><p><?= e($address) ?></p><?php endif; ?>
    </div>
  </div>
  <div class="wx-footer-bottom">
    <div class="wx-inner">
      <span><?= e($copyright) ?></span>
      <?php if ($icp): ?><a href="https://beian.miit.gov.cn" target="_blank" rel="nofollow"><?= e($icp) ?></a><?php endif; ?>
    </div>
  </div>
</footer>

<?= plugin_hook('front_footer') ?>

<script>
(function () {
  var btn = document.querySelector('.wx-menu-btn');
  var nav = document.querySelector('.wx-nav');
  if (btn && nav) {
    btn.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  var form = document.querySelector('.wx-contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = form.getAttribute('data-email') || '';
      var name = (form.querySelector('[name=name]') || {}).value || '';
      var phone = (form.querySelector('[name=phone]') || {}).value || '';
      var message = (form.querySelector('[name=message]') || {}).value || '';
      var body = '姓名：' + name + '\n电话：' + phone + '\n需求：\n' + message;
      window.location.href = 'mailto:' + email + '?subject=' + encodeURIComponent('网站询价 - ' + name) + '&body=' + encodeURIComponent(body);
    });
  }
})();
</script>
</body>
</html>
