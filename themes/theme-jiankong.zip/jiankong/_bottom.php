<?php
$copyright = setting('site_copyright', '© ' . date('Y') . ' ' . $siteName . ' 版权所有');
$icp = setting('site_icp', '');
$productCat = $newsCat = null;
foreach ($nav as $c) { if (($c['slug'] ?? '') === 'product') { $productCat = $c; } if (($c['slug'] ?? '') === 'news') { $newsCat = $c; } }
$slogan = setting('site_slogan', '让安全更早发生');
?>
</main>
<section class="cta-band">
  <div class="wrap cta-in">
    <div class="cta-orb"><span></span><i></i></div>
    <div><h2>Ready to make your<br>business safer?</h2><p>从现场勘测到系统交付，给我们 30 分钟，聊聊你的安防需求。</p></div>
    <a class="btn btn-white" href="<?= e($contactUrl) ?>">CONTACT US <span class="arrow">↗</span></a>
  </div>
</section>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="f-brand">
      <a class="brand" href="<?= e(lang_path('/')) ?>"><span class="brand-mark"><i></i></span><span class="brand-text"><b>CoSecu</b><span>SMART SECURITY</span></span></a>
      <p><?= e($slogan) ?>。为家庭、商业与信息场景提供可视、可控、可追溯的智能安防系统。</p>
      <div class="f-social"><a href="<?= e($contactUrl) ?>">产品咨询</a><a href="<?= e($contactUrl) ?>">预约勘测</a><?php if ($email): ?><a href="mailto:<?= e($email) ?>">邮箱</a><?php endif; ?></div>
    </div>
    <div class="f-col"><h4>产品中心</h4><?php if ($productCat): ?><a href="<?= e(lang_path('/c/' . $productCat['slug'])) ?>"><?= e($productCat['name']) ?></a><?php foreach (($productCat['children'] ?? []) as $ch): ?><a href="<?= e(lang_path('/c/' . $ch['slug'])) ?>"><?= e($ch['name']) ?></a><?php endforeach; ?><?php endif; ?></div>
    <div class="f-col"><h4>快速链接</h4><?php foreach ($navItems as $it): if (in_array($it['key'], ['solution', 'news', 'service', 'about', 'contact'], true)): ?><a href="<?= e($it['url']) ?>"><?= e($it['name']) ?></a><?php endif; endforeach; ?><a href="<?= e(lang_path('/search')) ?>">站内搜索</a></div>
    <div class="f-col f-contact"><h4>联系我们</h4><?php if ($phone): ?><b><?= e($phone) ?></b><?php endif; ?><?php if ($email): ?><a href="mailto:<?= e($email) ?>"><?= e($email) ?></a><?php endif; ?><?php if ($address): ?><span><?= e($address) ?></span><?php endif; ?><span>7×24 小时技术响应</span></div>
  </div>
  <div class="wrap footer-bottom"><span><?= e($copyright) ?></span><span><?php if ($icp): ?><a href="https://beian.miit.gov.cn" target="_blank" rel="nofollow"><?= e($icp) ?></a><?php endif; ?></span></div>
</footer>
<?= plugin_hook('front_footer') ?>
<script src="/theme/theme.js?v=2.0.0"></script>
</body>
</html>
