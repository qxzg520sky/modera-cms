<?php
$copyright = setting('site_copyright', '© ' . date('Y') . ' ' . $siteName . ' 版权所有');
$icp = setting('site_icp', '');
$productCat = $newsCat = null;
foreach ($nav as $c) {
    if (($c['slug'] ?? '') === 'product') { $productCat = $c; }
    if (($c['slug'] ?? '') === 'news') { $newsCat = $c; }
}
$slogan = setting('site_slogan', '让医疗软件更懂临床');
?>
</main>
<section class="cta-band">
  <div class="wrap cta-in">
    <div class="cta-mark">K</div>
    <div><h2>让数据回到临床，<br>让系统真正好用。</h2><p>预约一次产品演示，聊聊你的科室流程、数据接口与交付计划。</p></div>
    <a class="btn btn-red" href="<?= e($contactUrl) ?>">预约演示 <span class="arrow">↗</span></a>
  </div>
</section>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="f-brand">
      <a class="brand" href="<?= e(lang_path('/')) ?>"><span class="brand-mark"><i></i><i></i></span><span class="brand-text"><b><?= e($siteName) ?></b><span>KANGSOFT · 医疗科技</span></span></a>
      <p><?= e($slogan) ?>。专注医院信息化、临床数据与医疗运营数字化，为医疗机构提供可持续演进的产品与服务。</p>
      <div class="f-social"><a href="<?= e($contactUrl) ?>">产品咨询</a><a href="<?= e($contactUrl) ?>">解决方案</a><?php if ($email): ?><a href="mailto:<?= e($email) ?>">邮箱</a><?php endif; ?></div>
    </div>
    <div class="f-col"><h4>产品与方案</h4>
      <?php if ($productCat): ?><a href="<?= e(lang_path('/c/' . $productCat['slug'])) ?>"><?= e($productCat['name']) ?></a><?php foreach (($productCat['children'] ?? []) as $ch): ?><a href="<?= e(lang_path('/c/' . $ch['slug'])) ?>"><?= e($ch['name']) ?></a><?php endforeach; ?><?php endif; ?>
    </div>
    <div class="f-col"><h4>快速链接</h4>
      <?php foreach ($navItems as $it): if (in_array($it['key'], ['solution', 'news', 'service', 'about', 'contact'], true)): ?><a href="<?= e($it['url']) ?>"><?= e($it['name']) ?></a><?php endif; endforeach; ?>
      <a href="<?= e(lang_path('/search')) ?>">站内搜索</a>
    </div>
    <div class="f-col f-contact"><h4>联系我们</h4>
      <?php if ($phone): ?><b><?= e($phone) ?></b><?php endif; ?>
      <?php if ($email): ?><a href="mailto:<?= e($email) ?>"><?= e($email) ?></a><?php endif; ?>
      <?php if ($address): ?><span><?= e($address) ?></span><?php endif; ?>
      <span>周一至周五 09:00–18:00</span>
    </div>
  </div>
  <div class="wrap footer-bottom"><span><?= e($copyright) ?></span><span><?php if ($icp): ?><a href="https://beian.miit.gov.cn" target="_blank" rel="nofollow"><?= e($icp) ?></a><?php endif; ?></span></div>
</footer>
<?= plugin_hook('front_footer') ?>
<script src="/theme/theme.js?v=2.0.0"></script>
</body>
</html>
